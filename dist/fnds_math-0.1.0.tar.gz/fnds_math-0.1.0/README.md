# Fundametals Math

[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
A terminal game to learn fundametal concepts in mathematics